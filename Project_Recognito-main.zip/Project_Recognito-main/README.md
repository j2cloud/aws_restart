# Project Recognito

The goal of the Project is to use AWS Lambda Service to deploy a Serverless Image Recognition App.

A console application (S3Upload.py) was also developed to upload images into a S3 bucket.

When the image is uploaded to S3 bucket, the Lambda function triggers Amazon Rekognition to detect the image label and store the result in DynamoDB. 

Special thanks to the team members for their contribution

Supervisor: Dominic Singaraj
Mentor: 	Dipti Dihingia
Business Analyst: Albert Raymore
Development: Nzoji Hipolito, Chatlekha Klamruang, Chirag Limbachia, Gabriel Olaleye
Testing: Sasikala Reddipalli, Faiza Baqir
DevOps: Kehinde Olaleye, Judine Bras

